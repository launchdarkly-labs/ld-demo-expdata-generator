import requests
import json

project_key = "cxld-charitable-pause"
env_key = "production"
exp_key = "ai-chatbot-experiment"
api_key = "api-451cd896-2388-4aaa-a713-11807acdf8c6"

url = (
    "https://app.launchdarkly.com/api/v2/projects/"
    + project_key
    + "/environments/"
    + env_key
    + "/experiments/"
    + exp_key
    + "?expand=currentIteration,treatments"
)
headers = {
    "Authorization": api_key,
    "Content-Type": "application/json",
}
response = requests.get(url, headers=headers)
data = json.loads(response.text)
flag_key = list(data["currentIteration"]["flags"].keys())[0]
print(flag_data)
